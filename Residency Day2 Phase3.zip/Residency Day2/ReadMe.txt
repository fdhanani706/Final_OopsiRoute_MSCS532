# Phase 3: Optimization, Scaling, and Final Evaluation – OopsiRoute Project

## Overview
This project is the Phase 3 deliverable of the OopsiRoute assignment. The goal of this phase was to optimize the initial proof-of-concept implementation (Phase 2), scale it to handle larger datasets, and perform rigorous evaluation of performance and memory usage.

---

## Folder Structure
